//*/*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
package classactivity;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class ClassActivity {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Faculty f1 = new Faculty();
        f1.readData();
        f1.readValues();;
        f1.read();
        f1.DisplayDAta();
        f1.DisplayValues();
        f1.display();
    }
    
}

abstract class Person{
    
    String Name;    
    int age;
    
    abstract   void readData();
    abstract void DisplayDAta();
   
}

interface Employee{
    
//   String type;
//   int Salary;
   abstract void readValues();
    abstract void DisplayValues();
}

class Faculty extends Person implements Employee{

    
        String type;
        int salary;
        String Course;
        
        
       @Override
    void readData() {
       Scanner s1 = new Scanner(System.in);
       System.out.println("Enter NAme: ");
       super.Name = s1.next();
       System.out.println("Enter Age: ");
       super.age = s1.nextInt();
    }

    @Override
    void DisplayDAta() {
        System.out.println("Name: " +Name);
        System.out.println("Age: " +age);
    }
    

    @Override
    public void readValues() {
        
        
        Scanner s2 = new Scanner(System.in);
        System.out.println("Enter Type: PT/FT");
        type = s2.next();
        System.out.println("Enter Salary : ");
        salary = s2.nextInt();
    }

    @Override
    public void DisplayValues() {
        
        System.out.println("Job Type: " + type);
        System.out.println("Salary: " + salary);
       
    }
     void read(){
         Scanner s3 = new Scanner(System.in);
         System.out.println("Enter Course: ");
         Course = s3.next();
     } 
     void display(){
         
         System.out.println("Course: " + Course);
     }
}


   