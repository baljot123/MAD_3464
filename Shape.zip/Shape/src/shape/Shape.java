/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shape;

/**
 *
 * @author macstudent
 */
public class Shape {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    //    Myshape obj1 = new Myshape();  cannot create object of abstract class
       Circle c1 = new Circle();
       c1.draw();
       c1.display("This is a Circle");
    
    }
    
}

abstract class Myshape{
    int x;
    int y;
    
abstract void draw();
void display(String msg){
    System.out.println(msg);
}
    
}
 
class Circle extends Myshape{

    @Override
    void draw() {
      
        System.out.println("Draw Circle");
        super.x = 20;
        super.y = 30;
         System.out.println("x = " + super.x + " y = " +super.y);
    }

   
    
}

abstract class Rectangle extends Myshape{
    
       int h;
       
       abstract void draw();
       
}
    