/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day.pkg4arraylisters;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Day4ArrayListers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Books book1 = new Books(1,"The Sky",8);
        Books book2 = new Books(2,"Necklace",3); 
        Books book3 = new Books(3,"Hello",5); 
        Books book4 = new Books(4,"Journey",9); 
        Books book5 = new Books(5,"Wonder",7); 
        ArrayList<Books> Library = new ArrayList<Books>();
        
        Library.add(book1);
        Library.add(book2);
        Library.add(book3); 
        Library.add(book4);
        Library.add(book5);
        System.out.println("No. of Books: " + Library.size());
         
          
          
         Library.add(2,new Books(10,"Pacific",9));
//         
//         Library.forEach(bk ->{
//             bk.displayinfo();
//         });
//         
         Collections.sort(Library, new bookRatingComparator());
         for(Books bk: Library){
             bk.displayinfo();
         }
         
         
        
      //   for ( Books bk: Library){
            // bk.displayinfo();
       //  }
       // Scanner s1 = new Scanner(System.in);
       
       System.out.println("***************Student Information***********");
   
       Student st1 = new Student(1,"BAljot","#1");
       Student st2 = new Student(2,"Sansoya","#2");
       
       ArrayList<Student> Library1 = new ArrayList<Student>();
        
        Library1.add(st1);
        Library1.add(st2);
//        Library1.forEach(st ->{
//             st.displayInfo();
//        
//        });
         Collections.sort(Library1, new studentNameComparator());
         for(Student bk: Library1){
             bk.displayInfo();
         }
    }
    
}
