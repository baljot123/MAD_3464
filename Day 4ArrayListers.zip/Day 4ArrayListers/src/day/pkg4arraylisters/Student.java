/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day.pkg4arraylisters;

import java.util.Comparator;

/**
 *
 * @author macstudent
 */
public class Student {
    
     int rn;
    String name;
    String ID;
 
    Student(){
        this.rn = 0;
        this.name = "unknown";
        this.ID = "unknown";
        
    }    
    
    Student(int rn, String name, String ID)
    {
        this.rn = rn;
        this.name =  name;
        this.ID = ID;
    }
    
    void setrn(int rn){
        this.rn = rn;
    }
    
    int getrn(){
        return this.rn;
  
    }
    
    void setName(String title){
        this.name = name;
    }
    String getName(){
        return this.name;
    }
    
    void setID(int rate){
        this.ID = ID;
    }
    String getRating(){
        return this.ID;
    }
    
     void displayInfo()
    {
        System.out.println("Student Rollno: " + this.rn
        + "\nStudent NAme : " + this.name +
                "\nStudent Id: " + this.ID);
                
    }
   
    
    
}
    

class studentNameComparator implements Comparator<Student>{

    @Override
    public int compare(Student o1, Student o2) {
        
        return o2.name.compareToIgnoreCase(o1.name);
        
    }
    
}