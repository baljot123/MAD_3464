/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

import java.util.Scanner;

/**
 *
 * @author 728612
 */
public class Sample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      
       String Name;
       String Password;
       Scanner s1 = new Scanner(System.in);
       System.out.println("Enter NAme: ");
       Name = s1.nextLine();
       System.out.println("Enter Password: ");
       Password = s1.nextLine();
      
       
       if((Name.equals("text")) && (Password.equals("text")))
       {
           
           System.out.println("Welcome : Press 1 to view : ");
           int b;
           Scanner S1 = new Scanner(System.in);
           
           b= s1.nextInt();
           if(b==1){
                Ticket t1 = new Ticket();
                t1.sam();
                t1.display(); 
           }
       }
           
       else if(Name == "admin" && Password == "admin")
       {
           
           System.out.println("LOGIN AS ADMIN");
       }
      
       else{
           System.out.println("Does not match");
       }
       
    } 
    }
    

