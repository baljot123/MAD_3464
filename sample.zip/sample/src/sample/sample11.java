/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

/**
 *
 * @author 728612
 */


interface aa{
    
void display();   
}
abstract class sample11 {
    
    abstract void sam();
}

class Ticket extends sample11 implements aa{

    @Override
    void sam() {
       System.out.println("HEllo abstrat ");
    }

    @Override
    public void display() {
        System.out.println("Interface");
    }
    
}